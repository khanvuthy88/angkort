# -*- coding: utf-8 -*-

from . import hr_controller
# from . import product
from . import shop
from . import telegram_webhook
from . import auth
from . import res_partner
